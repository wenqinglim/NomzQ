define(['require'], function(require) {
    return {

        /**
         * Application constants. This values generated from all service settings.
         * Also there are Push Notification settings there if Push Notifications enabled for this project.
         */

        /**
         * Settings
         */
        Settings: {},
        /**
         * NomzQ_settings
         * @property database_id       - 
         */
        NomzQ_settings: {
            "database_id": "57fb7ccde4b0ce71faf931b2"
        }
    };
});