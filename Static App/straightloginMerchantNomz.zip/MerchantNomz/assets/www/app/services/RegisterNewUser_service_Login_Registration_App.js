/**
 * Module initializes rest service RegisterNewUser_service_Login_Registration_App
 */

define(['require'], function(require) {

    return [{
        type: 'service',
        name: 'RegisterNewUser_service_Login_Registration_App',
        deps: ['Apperyio', 'REST', RegisterNewUser_service_Login_Registration_AppImpl]
    }];

    /**
     * @function RegisterNewUser_service_Login_Registration_AppImpl
     */

    function RegisterNewUser_service_Login_Registration_AppImpl(Apperyio, REST) {

        var REST = new REST();

/**
         * REST options. Initial values of "headers", "params", "data" and "echo" store are stored in models.js.
         * @property {string} url                             - Absolute or relative URL of the resource that is being requested.
         * @property {string} method                          - HTTP method (e.g. 'GET', 'POST', etc)
         * @property {Object} headers                         - Map of strings or functions which return strings representing HTTP headers
                                                                to send to the server. If the return value of a function is null,
                                                                the header will not be sent.
         * @property {Object.<string, string|Object>} params  - Map of strings or objects which will be turned to ?key1=value1&key2=value2
                                                                after the url. If the value is not a string, it will be JSONified.
         * @property {string|Object} data                     - Data to be sent as the request message data.
         * @property {string} echo                            - If echo mode is on then service will return echo value instead of the rest response
         * @property {Object.<string, string>} aio_config     - Apperyio configuration object
         * @property {string} requestType                     - Request type
         * @property {string} responseType                    - Response type
         * @property {string} serviceName                     - Service name
         */

        this.config = {
            url: "https://api.appery.io/rest/1/code/{servercode}/exec",
            method: "post",
            headers: Apperyio.EntityAPI("RegisterNewUser_service_Login_Registration_App.request.headers"),
            params: Apperyio.EntityAPI("RegisterNewUser_service_Login_Registration_App.request.query"),
            data: Apperyio.EntityAPI("RegisterNewUser_service_Login_Registration_App.request.body"),
            aio_config: {
                requestType: "data",
                responseType: "json",
                serviceName: "RegisterNewUser_service_Login_Registration_App"
            }
        };
        this.inst = REST.setDefaults(this.config);
        return this.inst.execute;
    }
});