define([
/**
 * System global resources
 */
"require", "angular", "angular-touch", "angular-route", "Apperyio", "cordova", "constants", "routes", "bootstrap", "$App/crouterconfig", '$Screens/indexController',
/**
 * Angular modules
 */
"ionic", "gmaps", "angular-chart",

/**
 * Custom global resources
 */
"navigateTo", "backButton", "activeScreenManager", "NomzQ_login_service", "NomzQ_logout_service", "NomzQ_UserProfile_delete_service", "NomzQ_UserProfile_update_service", "NomzQ_UserProfile_read_service", "NomzQ_UserProfile_create_service", "NomzQ_Menu_read_service", "NomzQ_Menu_create_service", "NomzQ_UserProfile_query_service", "NomzQ_UserProfile_list_service", "NomzQ_Menu_query_service", "NomzQ_Menu_list_service", "NomzQ_Menu_delete_service", "NomzQ_Menu_update_service", "NomzQ_Dish_delete_service", "NomzQ_Dish_update_service", "NomzQ_Dish_read_service", "NomzQ_Dish_create_service", "NomzQ_Dish_list_service", "NomzQ_Dish_query_service", "NomzQ_Sales_create_service", "NomzQ_Sales_read_service", "NomzQ_Sales_update_service", "NomzQ_Sales_delete_service", "NomzQ_Sales_list_service", "NomzQ_Sales_query_service", "NomzQ_MerchantProfile_create_service", "NomzQ_MerchantProfile_read_service", "NomzQ_MerchantProfile_delete_service", "NomzQ_MerchantProfile_update_service", "NomzQ_MerchantProfile_query_service", "NomzQ_MerchantProfile_list_service", "NomzQ__files_upload_service", "chart", "Barcode", "LoginUser_service", "RegisterNewUser_service", "dataStorage", "LoginUser_service_Login_Registration_App", "RegisterNewUser_service_Login_Registration_App", "dataStorage_Login_Registration_App", "list_script_service", "NomzQ_Orders_create_service", "NomzQ_Orders_read_service", "NomzQ_Orders_update_service", "NomzQ_Orders_list_service", "NomzQ_Orders_delete_service", "update_script_service", "ready_service", "Twilio_SendSMS_service"], function() {
    var angular = require("angular"),
        _Appery = require("Apperyio"),
        routerConfig = require("$App/crouterconfig");
    var DEPENDENCIES_INDEX = 14;
    var DEPENDENCIES = Array.prototype.slice.call(arguments, DEPENDENCIES_INDEX);

    /**
     * Adding angular modules to the application
     */
    var APP = angular.module(window.__APPLICATION_NAME, ['ApperyioModule', "ionic", "uiGmapgoogle-maps", "angular-chart"]).config(["$routeProvider", '$controllerProvider', '$provide', '$locationProvider', '$compileProvider', '$filterProvider', 'uiGmapGoogleMapApiProvider', Configuration]).run(["Apperyio", "User", "$location", "$ionicPlatform", RUN]);

    function Configuration($routeProvider, $controllerProvider, $provide, $locationProvider, $compileProvider, $filterProvider, $uiGmapGoogleMapApiProvider) {

        APP.controller = $controllerProvider.register;
        APP.directive = $compileProvider.directive;
        APP.filter = $filterProvider.register;
        APP.factory = $provide.factory;
        APP.service = $provide.service;
        APP.provider = $provide.provider;
        APP.value = $provide.value;
        APP.constant = $provide.constant;
        APP.decorator = $provide.decorator;

        /**
         * Place for list of pages and routes
         */
        var routes = require('routes');
        APP.defaultRoute = routes['default']['redirectTo'];
        $locationProvider.html5Mode({
            enabled: false,
            requireBase: false
        });
        angular.forEach(routes.when, function(route, path) {
            $routeProvider.when(path, routerConfig(route, APP));
        });
        $routeProvider.otherwise(routes.otherwise || routes.
    default);
        /**
         * Global dependencies resolver
         */
        if (DEPENDENCIES.length >= 0) {
            var deps = null;
            for (var i = 0, l = DEPENDENCIES.length; i < l; i++) {
                deps = DEPENDENCIES[i];
                if (angular.isArray(deps) && deps.length > 0 && angular.isArray(deps[0].deps)) {
                    try {
                        for (var j = 0, l2 = deps.length; j < l2; j++) {
                            APP[deps[j].type].call(APP, deps[j].name, deps[j].deps);
                        }
                    } catch (e) {
                        // angular or service level error
                        e.message = 'Error in ' + deps[j].name + "\nMessage: " + e.message;
                        throw new Error(e);
                    }
                }
            }
        }
        APP.controller('indexController', require('$Screens/indexController'));
    }

    function RUN(Apperyio, User, $location, $ionicPlatform) {
        Apperyio.User = User;
        Apperyio.Config.init(require('constants'));
        $ionicPlatform.registerBackButtonAction(function(event) {
            if (APP.defaultRoute === $location.path()) {
                navigator.app.exitApp();
            } else {
                navigator.app.backHistory();
            }
        }, 100);
    }

    return APP;
});