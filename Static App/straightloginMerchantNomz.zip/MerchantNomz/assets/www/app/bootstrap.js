'use strict';

(function(window) {

    require.config({
        baseUrl: "app",
        paths: {
            'jasmine_f': '../libs/jasmine/lib/jasmine-core',
            'specs': '../test/specs',
            'angular-mocks': '../libs/angular-mocks/angular-mocks',
            'mocks': '../test/mocks',
            '$Libs': '../libs',
            '$App': '../libs/apperyio',
            '$Screens': 'pages',
            '$Modals': 'modals',
            '$Services': 'services',
            "navigateTo": "services/navigateTo",
            "backButton": "services/backButton",
            "text": "../libs/text",
            "require": "../libs/requirejs/require",
            "angular": "../libs/angular/angular.min",
            "angular-touch": "../libs/angular-touch/angular-touch.min",
            "angular-route": "../libs/angular-route/angular-route.min",
            "ionic": "../libs/ionic/ionic.bundle",
            "appery-ui": "../libs/appery-ui/appery-ui",
            "lodash": "../libs/lodash/dist/lodash.min",
            "gmaps": "../libs/angular-google-maps/angular-google-maps.min",
            "Apperyio": "../libs/apperyio/Apperyio",
            "q": "../libs/ms_sdk_bundle/q/q",
            "localforage": "../libs/ms_sdk_bundle/localforage/dist/localforage",
            "EventEmitter": "../libs/ms_sdk_bundle/EventEmitter.js/EventEmitter",
            "tv4": "../libs/ms_sdk_bundle/tv4/tv4",
            "ms-client-sdk": "../libs/ms_sdk_bundle/client-sdk",
            "CryptoJS": "../libs/ms_sdk_bundle/crypto-js-md5/crypto-js-md5",
            "moment": "../libs/ms_sdk_bundle/moment/moment",
            "cordova": "../libs/cordova",
            "x2js": "../libs/x2js/xml2json",
            "$App/crouterconfig": "../libs/apperyio/crouterconfig",
            "activeScreenManager": "services/activeScreenManager",
            "NomzQ_login_service": "services/NomzQ_login_service",
            "NomzQ_logout_service": "services/NomzQ_logout_service",
            "NomzQ_UserProfile_delete_service": "services/NomzQ_UserProfile_delete_service",
            "NomzQ_UserProfile_update_service": "services/NomzQ_UserProfile_update_service",
            "NomzQ_UserProfile_read_service": "services/NomzQ_UserProfile_read_service",
            "NomzQ_UserProfile_create_service": "services/NomzQ_UserProfile_create_service",
            "NomzQ_Menu_read_service": "services/NomzQ_Menu_read_service",
            "NomzQ_Menu_create_service": "services/NomzQ_Menu_create_service",
            "NomzQ_UserProfile_query_service": "services/NomzQ_UserProfile_query_service",
            "NomzQ_UserProfile_list_service": "services/NomzQ_UserProfile_list_service",
            "NomzQ_Menu_query_service": "services/NomzQ_Menu_query_service",
            "NomzQ_Menu_list_service": "services/NomzQ_Menu_list_service",
            "NomzQ_Menu_delete_service": "services/NomzQ_Menu_delete_service",
            "NomzQ_Menu_update_service": "services/NomzQ_Menu_update_service",
            "NomzQ_Dish_delete_service": "services/NomzQ_Dish_delete_service",
            "NomzQ_Dish_update_service": "services/NomzQ_Dish_update_service",
            "NomzQ_Dish_read_service": "services/NomzQ_Dish_read_service",
            "NomzQ_Dish_create_service": "services/NomzQ_Dish_create_service",
            "NomzQ_Dish_list_service": "services/NomzQ_Dish_list_service",
            "NomzQ_Dish_query_service": "services/NomzQ_Dish_query_service",
            "NomzQ_Sales_create_service": "services/NomzQ_Sales_create_service",
            "NomzQ_Sales_read_service": "services/NomzQ_Sales_read_service",
            "NomzQ_Sales_update_service": "services/NomzQ_Sales_update_service",
            "NomzQ_Sales_delete_service": "services/NomzQ_Sales_delete_service",
            "NomzQ_Sales_list_service": "services/NomzQ_Sales_list_service",
            "NomzQ_Sales_query_service": "services/NomzQ_Sales_query_service",
            "NomzQ_MerchantProfile_create_service": "services/NomzQ_MerchantProfile_create_service",
            "NomzQ_MerchantProfile_read_service": "services/NomzQ_MerchantProfile_read_service",
            "NomzQ_MerchantProfile_delete_service": "services/NomzQ_MerchantProfile_delete_service",
            "NomzQ_MerchantProfile_update_service": "services/NomzQ_MerchantProfile_update_service",
            "NomzQ_MerchantProfile_query_service": "services/NomzQ_MerchantProfile_query_service",
            "NomzQ_MerchantProfile_list_service": "services/NomzQ_MerchantProfile_list_service",
            "NomzQ__files_upload_service": "services/NomzQ__files_upload_service",
            "chart": "services/chart",
            "angular-chart": "services/angular-chart",
            "Barcode": "services/Barcode",
            "LoginUser_service": "services/LoginUser_service",
            "RegisterNewUser_service": "services/RegisterNewUser_service",
            "dataStorage": "services/dataStorage",
            "LoginUser_service_Login_Registration_App": "services/LoginUser_service_Login_Registration_App",
            "RegisterNewUser_service_Login_Registration_App": "services/RegisterNewUser_service_Login_Registration_App",
            "dataStorage_Login_Registration_App": "services/dataStorage_Login_Registration_App",
            "list_script_service": "services/list_script_service",
            "NomzQ_Orders_create_service": "services/NomzQ_Orders_create_service",
            "NomzQ_Orders_read_service": "services/NomzQ_Orders_read_service",
            "NomzQ_Orders_update_service": "services/NomzQ_Orders_update_service",
            "NomzQ_Orders_list_service": "services/NomzQ_Orders_list_service",
            "NomzQ_Orders_delete_service": "services/NomzQ_Orders_delete_service",
            "update_script_service": "services/update_script_service",
            "ready_service": "services/ready_service",
            "Twilio_SendSMS_service": "services/Twilio_SendSMS_service",
            '$charts_clone_1': 'pages/charts_clone_1',
            '$charts': 'pages/charts',
            '$Home': 'pages/Home',
            '$Business_Analytics': 'pages/Business_Analytics',
            '$About': 'pages/About',
            '$Welcome_Login_Registration_App': 'pages/Welcome_Login_Registration_App',
            '$Pending_Orders': 'pages/Pending_Orders',
            '$Completed_Orders': 'pages/Completed_Orders',
            '$Welcome': 'pages/Welcome',
            '$My_Account': 'pages/My_Account',
            '$Login': 'pages/Login'
        },
        waitSeconds: 100,
        shim: {
            "angular": {
                exports: "angular"
            },
            "angular-touch": {

                deps: ["angular"]
            },
            "angular-route": {

                deps: ["angular"]
            },
            "ionic": {

                deps: ["angular", "cordova"]
            },
            "appery-ui": {

                deps: ["angular"]
            },
            "lodash": {
                exports: "_"
            },
            "gmaps": {

                deps: ["angular"]
            },
            "CryptoJS": {
                exports: "CryptoJS"
            },
            "x2js": {
                exports: "X2JS"
            },

            'jasmine_f/boot': {
                deps: ['jasmine_f/jasmine-html']
            },
            'jasmine_f/jasmine-html': {
                deps: ['jasmine_f/jasmine']
            },
            'angular-mocks': {
                deps: ['angular', 'jasmine_f/boot']
            }
        }
    });

    define('angular', [], function() {
        return window.angular;
    });

    window.__APPLICATION_NAME = "AppModule_MerchantNomz";

    if (window.location.href.indexOf('tests.html') > -1) {
        require(["require", "angular", "app", '../test/tests_asset'], function() {});
    } else {
        require(["require", "angular", "app", "ionic", "appery-ui"], function(require, angular) {
            // Run APP
            angular.bootstrap(document.documentElement, [window.__APPLICATION_NAME]);
        });
    }
})(this);